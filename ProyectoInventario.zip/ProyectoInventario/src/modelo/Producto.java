
package modelo;

/**
 *
 * @author fuent
 */
public class Producto {
    
    //atributos
    private String codigo;
    private String nombre;
    private double precio;
    private int cantidad;
    
    //constructor

    public Producto(String codigo, String nombre, double precio, int cantidad) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    //metodo para actualizar el precio del producto
    public void actualizarPrecio(double nuevoPrecio){
        this.precio = nuevoPrecio;
    }
    
    //metodo para atualizar la cantidad de producto.
    public void actualizarCantidad(int nuevaCantidad){
        this.cantidad = nuevaCantidad;
    }
    
    //metodo para mostrar nombre del producto y cantidad
    public String mostrarNombreYCantidad(){
        return "Producto: [" + nombre + " / " + cantidad + " unidades / $ " + precio + " pesos.]";
    }
    
    //metodo para mostrar nombre el codigo y nombre.
    public String mostrarCodigoYNombre(){
        return "Producto: [" + codigo + " / " + nombre + "]";
    }
    
    //metodo para la descripción detallada del producto
    @Override
    public String toString() {
        return "Producto: [ " + " codigo = " + codigo + ", nombre = " + nombre + ", precio =" + precio + ", cantidad =" + cantidad + '}';
    }
    
   
}