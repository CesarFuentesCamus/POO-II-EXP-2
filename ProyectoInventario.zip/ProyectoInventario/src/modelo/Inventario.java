
package modelo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

/**
 *
 * @author fuent
 */
public class Inventario {
    
    private HashMap<String,Producto> productos;
    
    //constructor
    public Inventario(){
        productos= new HashMap<>();
    }

    public HashMap<String, Producto> getProductos() {
        return productos;
    }
    
    //metodo para agregar productos al inventario
    public boolean agregarProducto(Producto producto){
        if(productos.containsKey(producto.getCodigo())){
            System.out.println("El producto con código " + producto.getCodigo() + "ya existe.");
            return false;
        }else{
            productos.put(producto.getCodigo(), producto);
            return true;
            //System.out.println("Producto agregado con éxito.");
        }
    }
    
    //metodo para eliminar productos del inventario.
    public void eliminarProducto(String codigo){
        if(productos.containsKey(codigo)){
            productos.remove(codigo);
        }else{
            System.out.println("No se encontro ningun producto con el código " + codigo);
        }
    }
    
    //metodos para buscar productos por el codigo
    public Producto buscarProductoPorCodigo(String codigo){
        return productos.getOrDefault(codigo, null);
    }
    
    //metodo para buscar producto por nombre
    public Producto buscarProductoPorNombre (String nombre){
        for(Producto producto: productos.values()){
            if(producto.getNombre().equalsIgnoreCase(nombre)){
                return producto;
            }
        }
        return null;
    }

    //metodo para listar todos los productos en el inventario
    public void listarTodosLosProductos(){
        if(productos.isEmpty()){
            System.out.println("El inventario esta vacío.");
        }else{
            for(Producto producto: productos.values()){
                System.out.println(producto.mostrarNombreYCantidad());
            }
        }
    }
    
    //metodo ppara listar solo los productos disponibles
    public void listarProductosDisponibles(){
        boolean hayProductosDisponibles = false;
        
        for(Producto producto: productos.values()){
            if(producto.getCantidad() > 0){
                System.out.println(producto.mostrarNombreYCantidad());
                hayProductosDisponibles = true;
            }
        }
        if(!hayProductosDisponibles){
            System.out.println("No hay productos disponibles.");
        }
    }
    
    //metodo para generar informes del inventario
    public void generarInforme(){
        System.out.println("****** INFORME DEL INVENTARIO ******");
        System.out.println("Total de productos: " + productos.size());
        double valorTotal=0;
        for(Producto producto: productos.values()){
            valorTotal += producto.getPrecio() * producto.getCantidad();
        }
        System.out.println("Valor total del inventario: $ " + valorTotal);
    }
    
    public void cargaDeProductosDesdeCSV (String nombreArchivo){
        String linea;
        String rutaArchivo = "data/" + nombreArchivo;
        
        try(BufferedReader br = new BufferedReader (new FileReader(rutaArchivo))){
            br.readLine();
            
             while((linea = br.readLine()) != null){
                  String[] datos = linea.split(",");
                  String codigo = datos [0];
                  String nombre = datos [1];
                  double precio = Double.parseDouble(datos[2]);
                  int cantidad = Integer.parseInt(datos[3]);
            
           Producto producto = new Producto (codigo,nombre, precio, cantidad);   
           agregarProducto(producto);
           
           
        }
            System.out.println("Inventario cargado correctamente desde archivo CSV.");
    }catch(IOException e){
            System.out.println("Error al leer archivo: " + e.getMessage());
    }catch(NumberFormatException e){
            System.out.println("Error en el formato de los datos: " + e.getMessage());
    }
    }    
}
