
package controlador;

import java.util.Scanner;
import modelo.Inventario;
import modelo.Producto;


/**
 *
 * @author fuent
 */
public class Accion {
    
    private Inventario inventario;
    
    //cosntructor
    public Accion(Inventario inventario){
        this.inventario= inventario;
    }
    
    public Producto buscarProducto(Scanner scanner){
        boolean opcionValida=false;
        Producto producto= null;
        
        while(!opcionValida){
            System.out.println("Cómo desea buscar su producto ?");
            System.out.println("1.-Por código.");
            System.out.println("2.-Por nombre."); 
            int opcion = scanner.nextInt();
            scanner.nextLine();
            
            if(opcion ==1){
                 System.out.println("Ingrese el código del producto a buscar: ");
                 String codigo = scanner.nextLine();
                 producto = inventario.buscarProductoPorCodigo(codigo);
                  if(producto != null){
                      System.out.println("Producto encontrado: " + producto);
                      return producto;
                  }else{
                      System.out.println("Producto no encontrado.");
                      return null;
                  }
                  
            }else if(opcion ==2){
                 System.out.println("Ingrese el nombre del producto a buscar: ");
                 String nombre = scanner.nextLine();
                 producto = inventario.buscarProductoPorNombre(nombre);
                  if(producto != null){
                      System.out.println("Producto encontrado: " + producto);
                      return producto;
                  }else{
                      System.out.println("Producto no encontrado.");
                      return null;
                  }
                     
        }else{
                System.out.println("Opción no válida. Inténtelo de nuevo.");        
            }
        }
        return null;
    }
    
    public void agregarProducto(Scanner scanner){
        
            System.out.println("Ingrese el código del producto: ");
            String codigo = scanner.nextLine();
            String nombre = Validacion.validadNombre(scanner);
            double precio = Validacion.validarPrecio(scanner);
            int cantidad = Validacion.validarCantidad(scanner);
        
            Producto nuevoProducto = new Producto (codigo,nombre,precio,cantidad);
            
            boolean agregado = inventario.agregarProducto(nuevoProducto);
            
            if(agregado){
                  System.out.println("Producto agregado con éxito.");
            }
        
    }
    
    public void modificarProducto(Scanner scanner){
        Producto producto = buscarProducto(scanner);
        
        if(producto != null){
            boolean opcionValida=false;
            
            while(!opcionValida){
                 System.out.println("¿Qué desea modificar del producto?.");
                 System.out.println("1.- Modificar precio.");
                 System.out.println("2.- Modificar cantidad."); 
                 int opcion = Validacion.obtenerOpcion(scanner);
                 
                 switch(opcion){
                     case 1:
                          System.out.println("Ingrese el nuevo precio.");
                          double nuevoPrecio = Validacion.validarPrecio(scanner);
                          producto.setPrecio(nuevoPrecio);
                          System.out.println("Precio actualizado con éxito.");
                          opcionValida = true;
                          break;
                     case 2:
                          System.out.println("Ingrese el nuevo precio.");
                          int nuevaCantidad = Validacion.validarCantidad(scanner);
                          producto.setCantidad(nuevaCantidad);
                          System.out.println("Cantidad actualizada con éxito.");
                          opcionValida = true;
                          break;
                     default:
                         System.out.println("Opción no válida. Inténtelo de nuevo.");
                 }  
            }
        }else{
            System.out.println("Producto no encontrado");
        }
    }
    
    public void eliminarProducto(Scanner scanner){
        System.out.println("Lista de produtos: ");
        for(Producto producto : inventario.getProductos().values()){
            System.out.println(producto.mostrarCodigoYNombre());
        }
        
        System.out.println("Ingrese el código del producto a eliminar");
        String codigo = scanner.nextLine();
        
        Producto producto = inventario.buscarProductoPorCodigo(codigo);
        
        if(producto != null){
            System.out.println("¿Está seguro que desea eliminar el producto : " + producto.mostrarCodigoYNombre() + "(S/N)");
            String confirmacion = scanner.nextLine();
            
            if(confirmacion.equalsIgnoreCase("S")){
                inventario.eliminarProducto(codigo);
                System.out.println("Producto eliminado con éxito.");
            }else{
                System.out.println("Operación cancelada.");
            }
        }else{
            System.out.println("No se encontró un producto con el código " + codigo);
        }
    }
    
    public void listarProductos(Scanner scanner){
        boolean opcionValida = false;
        
        while(!opcionValida){
            System.out.println("¿Cómo desea listar sus productos?.");
            System.out.println("1.-Listar todos los productos.");
            System.out.println("2.-Listar productos disponibles.");
            int opcion = Validacion.obtenerOpcion(scanner);
            
            switch(opcion){
                case 1:
                    inventario.listarTodosLosProductos();
                    opcionValida = true;
                    break;
                case 2:
                    inventario.listarProductosDisponibles();
                    opcionValida = true;
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
    }
    
    public void generarInforme(){
        inventario.generarInforme();
    }
}
