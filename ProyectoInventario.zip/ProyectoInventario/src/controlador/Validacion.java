
package controlador;

import java.util.Scanner;

/**
 *
 * @author fuent
 */
public class Validacion {
    
    //metodo para validad que el nombre solo contenga letra
    public static String validadNombre(Scanner scanner){
       String nombre = ""; 
       boolean nombreValido=false;
       
       while(!nombreValido){
           System.out.println("Ingrese el nombre del producto (solo letras): ");
           nombre= scanner.nextLine();
           if(nombre.matches("[a-zA-Z]+")){
               nombreValido=true;
           }else{
               System.out.println("Nombre no válido. Por favor, ingrese solo letras.");
           }
       }
       return nombre;
    }
    
    //metodo para validar el precio(double)
    public static double validarPrecio(Scanner scanner){
        double precio=0.0;
        boolean precioValido=false;
        
        while(!precioValido){
            try{
                System.out.println("Ingrese el precio del producto: ");
                precio = Double.parseDouble(scanner.nextLine());
                precioValido=true;
            }catch(NumberFormatException e){
                System.out.println("Error: El precio debe ser un número. Inténtelo de nuevo.");
            }
        }
        return precio;
    }
    
    //metodo para validar la cantidad
    public static int validarCantidad (Scanner scanner){
        int cantidad=0;
        boolean cantidadValida=false;
        
        while(!cantidadValida){
            try{
                System.out.println("Ingrese la cantidad de producto: ");
                cantidad= Integer.parseInt(scanner.nextLine());
                cantidadValida=true;
            }catch(NumberFormatException e){
                System.out.println("Error: La cantidad debe ser un número entero. Inténtelo de nuevo.");
            }
        }
        return cantidad;
    }
    
    public static int obtenerOpcion(Scanner scanner){
        int opcion= -1;
        boolean entradaValida=false;
        
        while(!entradaValida){
            try{
                System.out.println("Selecciona una opción: ");
                opcion= Integer.parseInt(scanner.nextLine());
                entradaValida=true;
            }catch(NumberFormatException e){
                System.out.println("Entrada no válida. Por favor, ingrese un número");
            }
        }
        return opcion;
    }
}
