
package vista;

import controlador.Accion;
import java.util.Scanner;
import modelo.Inventario;
import modelo.Producto;
import controlador.Validacion;

/**
 *
 * @author fuent
 */
public class MenuPrincipal {
    
    
    private static Inventario inventario = new Inventario();
    private static Scanner scanner = new Scanner(System.in);
    private static Accion accion= new Accion(inventario);
   
    public static void main(String[] args) {
        
        //cargar inventario desde el archivo CSV en la carpeta data
        inventario.cargaDeProductosDesdeCSV("inventario.csv");
        
        boolean salir = false;
        
        while(!salir){
            mostrarMenu();
            int opcion = Validacion.obtenerOpcion(scanner);
            
            switch(opcion){
                case 1:
                    accion.agregarProducto(scanner);
                    break;
                case 2:
                    accion.eliminarProducto(scanner);
                    break;
                case 3:
                    accion.buscarProducto(scanner);
                    break;
                case 4:
                    accion.listarProductos(scanner);
                    break;
                case 5:
                    accion.generarInforme();
                    break;
                case 6:
                    accion.modificarProducto(scanner);
                    break;
                case 7:
                    salir=true;
                    System.out.println("Saliendo del sistema...");
                    break;
                    
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
                              
            }
        }
    }
    
    private static void mostrarMenu(){
        System.out.println("***** MENU PRINCIPAL *****");
        System.out.println("1.- Agregar producto.");
        System.out.println("2.- Eliminar producto.");
        System.out.println("3.- Buscar producto.");
        System.out.println("4.- Listar todos los productos.");
        System.out.println("5.- Generar informe.");
        System.out.println("6.- Modificar producto.");
        System.out.println("7.- Salir.");
        //System.out.println("Selecciona una opción: ");
        
    }
    
}
